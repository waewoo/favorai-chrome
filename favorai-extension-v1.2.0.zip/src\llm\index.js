import { queryOpenAI }  from './providers/openai.js';
import { queryGemini }  from './providers/gemini.js';
import { queryMistral } from './providers/mistral.js';
import { queryOllama }  from './providers/ollama.js';
import { queryCustom }  from './providers/custom.js';

const SYSTEM_PROMPT_COMMON = `You are an assistant specialized in organizing web browser bookmarks.
You are provided with a bookmark tree in JSON format.
Your task is to reorganize this structure according to the requested mode, strictly following these rules:

STRICT RULES:
1. You MUST return ONLY a valid JSON object with two main keys:
   - "reorganizedTree": the complete reorganized structure.
   - "explanation": a global explanation of the reorganization (in the user's language).
2. To optimize speed and reduce response size, you MUST OMIT the "url" field in the output "reorganizedTree". Only return:
   - A bookmark: { "id": "string", "title": "string" }
   - A folder:   { "id": "string", "title": "string", "children": [...] }
3. Do NOT lose ANY bookmark. All "id" values present in the input JSON must exist in the output JSON.
4. Keep the "id" for all existing bookmarks and folders so movements can be identified.
5. If you need to create a folder, assign it a temporary ID starting with "new_" (e.g.: "new_folder_1", "new_folder_dev").`;

const PROMPT_MINIMAL = `MODE: Minimal reorganization.
Specific rules:
- Only move individual bookmarks that appear misplaced or orphaned.
- STRICTLY RESPECT the existing folder structure.
- NEVER rename an existing folder.
- NEVER move an existing folder.
- Do NOT delete existing folders.
- Do NOT reinvent the entire tree.
- Create a new folder only if absolutely necessary for a bookmark that fits no current folder.
- The global folder structure must remain unchanged. Only bookmarks themselves may be moved.`;

const PROMPT_COMPLETE = `MODE: Complete reorganization.
Specific rules:
- You may rethink the entire folder organization if you deem it relevant.
- You may create new folders, rename existing ones, merge folders, or move entire folders.
- You may propose a clean, thematically organized tree (e.g.: "Development", "Leisure", "Finance", "News", etc.).
- Clearly explain your structural choices in the "explanation" field to help the user understand the changes.`;

/**
 * Route la requête vers le bon provider LLM.
 * @param {object} config  - { provider, apiUrl, apiKey, modelName, customPrompt }
 * @param {object} bookmarksTree - Arborescence nettoyée (sans URLs)
 * @param {string} mode    - 'minimal' | 'complete'
 * @param {AbortSignal} signal
 */
export async function queryLLM(config, bookmarksTree, mode, signal) {
  const { provider, apiUrl, apiKey, modelName, customPrompt } = config;

  const systemPrompt = customPrompt?.trim()
    ? `${SYSTEM_PROMPT_COMMON}\n\nADDITIONAL USER INSTRUCTIONS (FOLLOW STRICTLY):\n${customPrompt.trim()}`
    : SYSTEM_PROMPT_COMMON;

  const modeInstruction = mode === 'complete' ? PROMPT_COMPLETE : PROMPT_MINIMAL;
  // JSON sans indentation pour économiser les tokens LLM
  const userPrompt = `${modeInstruction}\n\nHere is the JSON of my current bookmarks to reorganize:\n\n${JSON.stringify(bookmarksTree, null, 2)}`;

  switch (provider) {
    case 'openai':
      return queryOpenAI(apiUrl || 'https://api.openai.com/v1', apiKey, modelName || 'gpt-4o-mini', userPrompt, systemPrompt, signal);
    case 'google':
      return queryGemini(apiUrl || 'https://generativelanguage.googleapis.com', apiKey, modelName || 'gemini-1.5-flash', userPrompt, systemPrompt, signal);
    case 'mistral':
      return queryMistral(apiUrl || 'https://api.mistral.ai/v1', apiKey, modelName || 'mistral-small-latest', userPrompt, systemPrompt, signal);
    case 'grok':
      return queryOpenAI(apiUrl || 'https://api.x.ai/v1', apiKey, modelName || 'grok-2', userPrompt, systemPrompt, signal);
    case 'ollama':
      return queryOllama(apiUrl || 'http://localhost:11434', modelName || 'llama3', userPrompt, systemPrompt, signal);
    case 'custom':
      return queryCustom(apiUrl, apiKey, modelName, userPrompt, systemPrompt, signal);
    default:
      throw new Error(`Unknown LLM provider: ${provider}`);
  }
}