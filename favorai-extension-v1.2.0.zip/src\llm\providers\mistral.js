import { cleanAndParseJSON, fetchWithTimeout } from '../utils.js';

export async function queryMistral(url, key, model, prompt, systemPrompt, signal) {
  const endpoint = `${url.replace(/\/$/, '')}/chat/completions`;
  const response = await fetchWithTimeout(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: prompt }
      ],
      response_format: { type: 'json_object' },
      temperature: 0.1,
      max_tokens: 8192
    }),
    signal
  });
  if (!response.ok) {
    const err = await response.text();
    const e = new Error(`Erreur Mistral (${response.status}): ${err}`);
    if (response.status === 429) e.isRateLimit = true;
    throw e;
  }
  const data = await response.json();
  return cleanAndParseJSON(data.choices[0].message.content);
}
