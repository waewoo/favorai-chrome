import { cleanAndParseJSON, fetchWithTimeout } from '../utils.js';

export async function queryOllama(url, model, prompt, systemPrompt, signal) {
  const endpoint = `${url.replace(/\/$/, '')}/api/chat`;
  const response = await fetchWithTimeout(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: prompt }
      ],
      stream: false,
      format: 'json',
      options: {
        temperature: 0.1,
        num_predict: 8192,
        num_ctx: 16384
      }
    }),
    signal
  });
  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Erreur Ollama (${response.status}): ${err}`);
  }
  const data = await response.json();
  return cleanAndParseJSON(data.message.content);
}
